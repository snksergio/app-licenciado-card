# Handoff · Reconhecimento V2 para React Native

## O que é

A V2 deixa o card de Reconhecimento da home enxuto, perto do original do Figma, com uma linha a mais: dias qualificados. O card inteiro (e o link "Ver toda jornada") abre a tela "Minha jornada", que junta graduação, faixa, prévia, PRO por vertical, próxima graduação e histórico. Cada mês do histórico abre um bottom sheet com o detalhe daquele mês.

A fonte da verdade é `../prototipo-v2.html`. Este pacote não muda o desenho: só organiza o mesmo desenho pra virar RN quase direto.

### Telas e estados

| Tela | Estados |
|---|---|
| Home, card enxuto | Dias em andamento (62/90) · meta batida (195 dias) |
| Minha jornada, topo | Aberto · recolhido, com a barra branca de atalhos |
| Sua faixa | Linha do tempo Setembro → Outubro → Novembro (variação C) |
| Sua prévia | Sem PRO 360 (prévia reduzida) · PRO 360 garantido (prévia cheia) |
| PRO por vertical | Aba Hoje · aba Em Novembro · "O que é GP e Rede?" aberto ou fechado |
| Rumo a Executivo | Meia-lua em andamento · meta batida |
| Histórico de Green Points | Gráfico de 6 meses e lista de meses |
| Sheet do mês | Mês atual (em andamento) · mês fechado |
| Celular de 320 px | PRO por vertical em três linhas |

Ficam de fora: variações A e B da faixa, "Anel e lista" em Rumo a Executivo, modo escuro e o painel lateral do protótipo.

## Arquivos

- `index.html`: todas as telas e estados lado a lado. Abre direto no navegador.
- `theme.ts`: tokens (cores, espaçamento, raios, tipografia, degradês, sombras).
- `tipos.ts`: contrato de dados e `dadosExemplo` com os números do protótipo.

O `theme` e o `dadosExemplo` dentro do `index.html` são cópia dos `.ts`. Se mudar um `.ts`, atualize a cópia.

## Como ler o index.html

- `data-rn` diz a primitiva: `View`, `Text`, `Pressable`, `Svg` (react-native-svg), `LinearGradient` (expo-linear-gradient), `ScrollView`.
- `data-component` marca a raiz de cada componente. No inspetor, cada um começa com `<!-- RN: Nome | props: ... -->`.
- Cada classe é uma chave de `StyleSheet.create`. Duas classes = `style={[styles.a, styles.b]}`.
- `var(--colorPrimary)`, `var(--space16)`, `var(--radius20)`, `font: var(--typeCardLevel)`: o nome é a chave no `theme.ts`.
- Cada componente é uma função JS com o mesmo nome, que recebe props e devolve a árvore. As funções `*Screen` e `*Section` mostram como os dados de `tipos.ts` viram props.
- Todo `Text` declara cor, fonte, tamanho e altura de linha. Nada herda de `View`, como no RN.
- O CSS imita o Yoga: contêiner em coluna, `flexShrink: 0`, `minWidth: 0`. Texto que precisa quebrar dentro de uma linha tem `flex: 1` ou `flexShrink: 1`.
- A caixa "Mostrar as caixas de cada primitiva", no topo, contorna cada View, Text, Pressable, Svg e LinearGradient.
- As classes têm o nome do componente na frente (`kpiTile...`) porque o CSS é global. No RN, com um StyleSheet por arquivo, dá pra tirar o prefixo.
- `gap`, `rowGap` e `columnGap` precisam de RN 0.71 ou mais novo.

## Inventário de componentes

Novos na V2:

| Componente | Props | Filhos | RN e biblioteca |
|---|---|---|---|
| `RecognitionCard` | graduationName, sealColor, kwh, previewToday, nextGraduationName, nextGoalKwh, progressPct, days, gpPanel, onPress | GraduationSeal, ProgressRing, DaysQualifiedRow, GreenPointsPanel, RadialGlow, GridOverlay, Icon | Pressable, View, Text, LinearGradient |
| `GreenPointsPanel` | monthName, gp, nextMonthName, nextRatePct, graduationName, baseRatePct, eliteRatePct, eliteMinGp | ProgressBar ×2 | View, Text |
| `DaysQualifiedRow` | days, goal, done, pct | ProgressBar, Icon | View, Text |
| `ProgressRing` | pct, label, accessibilityLabel | — | View, Text, Svg (Circle) |
| `ProgressBar` | pct, track, size, fill, accessibilityLabel | — | View |
| `GraduationSeal` | color, size | — | Svg (Circle, Line, Text). Selo ilustrativo |
| `JourneyScreen` | data | JourneyHeader, JourneyBody, ShortcutBar, MonthSheet | Animated.ScrollView (Reanimated) |
| `JourneyHeader` | title, graduationName, sealColor, nextGraduationName, kwh, nextGoalKwh, progressPct, kpis, scrollY | GraduationSeal, ProgressBar, KpiTile ×4, RadialGlow, GridOverlay | Animated.View, View, Text, Pressable, LinearGradient |
| `KpiTile` | label, value, unit?, tone?, progressPct?, onPress | Icon, ProgressBar | Pressable, View, Text |
| `ShortcutBar` | title, subtitle, sealColor, chips, active, visible, onPressChip | Chip, GraduationSeal | Animated.View, ScrollView horizontal |
| `Chip` | label, active, onPress | — | Pressable, Text |
| `JourneyBody` · `JourneySection` | data, sections · id, title, right?, children | SectionTitle e a seção | View |
| `SectionTitle` | title, right? | LiveBadge ou fração | View, Text |
| `LiveBadge` | label, solid | — | View, Text |
| `Badge` | label, tone (up, down, neutral), size (md, sm) | — | View, Text |
| `GoalTag` | label, done | Icon | View, Text |
| `BandTimeline` | nodes, rule, compact | Icon | View, Text |
| `PreviewCard` | previewToday, previewElite, full, statusMonthName, nextMonthName, opportunities, graduation | OpportunityRow, RadialGlow, GridOverlay | View, Text, LinearGradient (fundo e aviso) |
| `OpportunityRow` | kind (pro, elite, done), title, amount, detail, progressPct?, first | Icon, ProgressBar | View, Text |
| `ProVerticalList` | tabs, selected, caption, rows, compact, disclosure, onChangeTab | SegmentedTabs, ProVerticalRow, InfoDisclosure | View, Text |
| `ProVerticalRow` | vertical, name, badge?, amount, gain?, note?, detail, compact, first | IconCircle, Badge | View, Text |
| `SegmentedTabs` | options, selected, onChange | — | View, Pressable, Text |
| `IconCircle` | vertical, compact | Icon | View |
| `InfoDisclosure` | title, body, open, onToggle | Icon | Pressable, View, Text |
| `DaysGauge` | days, goal, done, pct, graduationName | GoalTag | View, Text, Svg (Path, Circle, LinearGradient do svg) |
| `RequirementRow` | label, current, goal, first | Icon, ProgressBar | View, Text |
| `HistoryChart` | tabs, selected, title, months, maxGp, eliteMinGp, graduationName, onPressMonth | SegmentedTabs | Pressable (barras), View, Text, Svg (Pattern das listras, Line pontilhada) |
| `MonthRow` | name, year, sealColor, inProgress, sub, subTone, gp, ratePct, first, onPress | GraduationSeal, LiveBadge, Icon | Pressable, View, Text |
| `MonthSheet` | title, inProgress, hasPrev, hasNext, summary, proTitle, proRows, proNote, origin, onClose, onPrev, onNext | MonthSummaryCard, ProMonthRow, InsetNote, PointsOriginList | @gorhom/bottom-sheet ou Modal, ScrollView |
| `MonthSummaryCard` | sealColor, graduationName, bandLabel, nextMonthName, ratePct, gpLabel, gp, badge, bands, info | GraduationSeal, Badge, ProgressBar ×2, InfoBar | View, Text |
| `InfoBar` · `InsetNote` | children · tone (ok, plain), children | Icon | View, Text |
| `ProMonthRow` | vertical, name, badge, first | IconCircle, Badge | View, Text |
| `PointsOriginList` | items | ProgressBar | View, Text |
| `Icon` | name, size, color | — | Svg com `color` e `stroke="currentColor"` |
| `RadialGlow` | token do theme | — | Svg com RadialGradient |
| `GridOverlay` | lineOpacity, fadeFrom, fadeTo | — | Svg com Pattern e Mask |

Contexto, já existe no app e só aparece pra montar a tela: `HomeScreen`, `HomeHeader`, `TabBar`, `SectionHeader`, `StatusBarMock` (no app é a barra do sistema: `expo-status-bar`).

## Bibliotecas sugeridas

- **react-native-svg**: anel, meia-lua, selos, ícones, brilho radial, grade e listras do gráfico.
- **expo-linear-gradient**: fundo do card, do topo da jornada, do card da prévia e do aviso "Reduzida/Cheia".
- **react-native-reanimated** (ou `Animated` do RN): topo que recolhe e barra branca.
- **@gorhom/bottom-sheet** (ou `Modal`): sheet do mês.
- **@expo-google-fonts/outfit**: a fonte. No RN cada peso é uma família (`Outfit_600SemiBold`), já escrita no `theme.typography`.
- **Pressable com `hitSlop`**: alvos menores que 44 px (detalhe em Acessibilidade).

Degradê radial: o expo-linear-gradient só faz linear. O brilho de cima do card, do topo e da prévia virou `RadialGlow` (Svg). A conversão está no comentário de `gradients` no `theme.ts`.

## Topo que recolhe (paralaxe)

Os números saem de `onDashScroll()` no protótipo (l.1048–1067).

- `topH` = altura do `JourneyHeader` (426 em 360 px; meça com `onLayout`).
- `barH` = altura da `ShortcutBar` (138; meça com `onLayout`).
- `fadeEnd = max(1, topH − barH)` → 288.
- `p = clamp(scrollY / fadeEnd, 0, 1)`.

| O quê | Fórmula |
|---|---|
| Topo, posição | `translateY = min(scrollY, topH) × 0,6`. O topo anda a 40% da velocidade da rolagem |
| Véu escuro sobre o topo | `opacity = p × 0,55` (`View` preto por cima de tudo no topo) |
| Conteúdo do topo (graduação, barra, 4 números) | `opacity = max(0, 1 − p × 1,15)` e `scale = 1 − p × 0,06`, com origem no topo |
| Barra branca | aparece quando `scrollY > fadeEnd − 24` (264). Entra em 220 ms: opacidade 0 → 1 e `translateY` −12 → 0. Escondida, `pointerEvents="none"` |

A linha do "Voltar" e o título "Minha jornada" não somem: ficam sob o véu e depois sob a barra.

Montagem sugerida com Reanimated:

- `useAnimatedScrollHandler` grava `scrollY`.
- `JourneyHeader` e `JourneyBody` ficam dentro do `Animated.ScrollView`. O corpo vem depois no código, então passa por cima. Ele tem `marginTop: -24`, cantos de 24 em cima e a sombra `shadows.shadowJourneyBody`.
- A `ShortcutBar` fica fora do ScrollView, em `position: 'absolute'`, `top: 0`, `zIndex: 5`.
- `transformOrigin: 'top'` precisa de RN 0.73 ou mais novo. Antes disso, compense a escala com `translateY`.
- Android: `elevation` não faz sombra pra cima. Sem ela o corpo fica sem a sombra da borda. Um degradê de 24 px acima do corpo pode imitar (sugestão, validar com design).

Atalhos e seções:

- Seção ativa: a última cujo topo está acima de `barH + 40` na tela. O atalho dela fica escuro, e a fileira de atalhos rola pra deixá-lo no centro.
- Toque num atalho ou num dos 4 números: rola até `yDaSeção + 12 − barH` (o título fica 12 px abaixo da barra). Prévia de hoje → Sua prévia. Green Points e Faixa atual → Sua faixa. Dias qualificados → Rumo a Executivo.
- Com "reduzir movimento" ligado (`useReducedMotion`), sem animação: a rolagem pula e a barra só aparece. O protótipo faz o mesmo.

## Sheet do mês

- Abre ao tocar num mês do gráfico ou da lista. O mês atual e o fechado têm o mesmo formato.
- Altura máxima de 88% da tela. O conteúdo rola por dentro. Fundo escurecido `colorScrim`.
- Setas no topo trocam de mês. Sem mês anterior ou seguinte, a seta fica com opacidade 0,35 e desligada.
- Fecha tocando na alça, no fundo ou no voltar do Android. Ao fechar, o foco volta pra onde estava.
- Entrada no protótipo: 320 ms, `cubic-bezier(.2,.8,.2,1)`.

## Layout em 320 px

Vale quando a largura da tela é até 340 px (`layout.compactMaxWidth`). No RN, `useWindowDimensions().width <= 340`. O que muda (l.446–474):

- Padding lateral do corpo da home e da jornada: 24 → 20.
- **PRO por vertical em três linhas**: nome e valor / selo e "se bater o PRO" / detalhe. Ícone de 32 (traço de 15) alinhado no topo. Linha com padding 14 16. Abas com padding 14 16 4, legenda com 10 16 6. Sem selo (Expansão), o detalhe sobe pra segunda linha.
- Card: a linha Prévia · anel · Executivo perde o padding lateral e o gap vai pra 4. Valores de 14 → 13.
- Painel de Green Points do card: padding 14. Rótulos 12 → 11 e podem quebrar linha. A coluna da direita usa até 42% da largura.
- Linha de dias qualificados: sem padding lateral.
- Títulos de linha de lista podem quebrar (nome e selo).
- 4 números do topo: padding lateral 20, valor 17 → 15.
- Prévia de hoje: 28 → 24.
- Sua faixa: valores 16 → 15, padding lateral 12 → 6.

O `index.html` mostra só PRO por vertical em 320, como pedido. Os demais ajustes estão listados aqui.

## Acessibilidade

- **Anel do card**: `accessibilityRole="image"`, `accessibilityLabel="Progresso até Executivo: 51%"`.
- **Meia-lua**: `accessibilityLabel="Dias qualificados: 62 de 90"` (o protótipo já tem esse texto).
- **Barras**: `accessibilityRole="progressbar"`, `accessibilityValue={{ min: 0, max: 100, now }}` e um `accessibilityLabel` com o número escrito, como "kWh qualificáveis: 152.340 de 300.000". Os textos estão no `aria-label` de cada barra no `index.html`.
- **Card da home**: um só alvo, `accessibilityLabel="Reconhecimento. Abrir minha jornada"`. A seta branca é decorativa.
- **Barras do gráfico**: tocáveis, "Maio, 1.320 GP". O mês atual: "Outubro, 1.240 GP, em andamento".
- **Linhas de mês**: "Outubro de 2026, 1.240 GP. Abrir o detalhe do mês".
- **Sheet**: `accessibilityViewIsModal`. Ao abrir, o foco vai pro sheet; ao fechar, volta pro mês tocado (o protótipo faz assim).
- **Alvos de toque**: `hitSlop` aumenta a área sem mudar o desenho. É recomendação, não regra do design.
  - Setas do sheet (32 px): `hitSlop={6}`.
  - Voltar da barra branca (28 px): `hitSlop={8}`.
  - Atalhos da barra (cerca de 30 px de altura): `hitSlop={{ top: 7, bottom: 7 }}`.
  - Abas (34 px): `hitSlop={{ top: 5, bottom: 5 }}`.
  - Barras do gráfico: `hitSlop={{ left: 5, right: 5 }}`.

## Diferenças em relação ao protótipo

Tudo foi medido lado a lado em 360 e 320 px. As alturas de card, topo, seções, linhas e sheet batem com o protótipo. O que mudou de forma, sem mudar o desenho:

- Brilho radial, grade de linhas e listras do mês atual viraram Svg. No protótipo são `radial-gradient`, `::before` com `mask-image` e `repeating-linear-gradient`.
- O aviso "Reduzida/Cheia" perdeu o `backdrop-filter: blur`. O fundo atrás é liso e não muda nada. Se quiser, `expo-blur`.
- Contorno do mês atual no gráfico: `outline` virou um `View` com borda por fora. Linha "Elite": borda pontilhada virou linha tracejada em Svg (borda pontilhada de um lado só não funciona bem no RN).
- Barra branca: a linha de baixo (`box-shadow 0 1px 0`) virou borda de 1 px. A barra fica com 139 px em vez de 138.
- Onde o protótipo mistura dois tamanhos de fonte na mesma linha, a linha cresce. Nos 4 números (+2 px) e no "1.240 GP" do sheet (+6 px), um `paddingBottom` iguala. Sobram 2,5 px de diferença em dois pontos: o título do sheet do mês atual e a primeira linha do histórico, onde o selo "Em andamento" quebra linha.
- Barra branca parada: a fileira de atalhos começa na esquerda. No protótipo ela rola pra centralizar o atalho ativo.
- Raios de 9 px, 99 px e 50% viraram `radiusPill`. O desenho é o mesmo.
- O sheet aparece inteiro no `index.html`. No app ele ocupa até 88% da tela.

## Pendências de negócio

Copiadas sem mudança de sentido. Os números do protótipo são de exemplo.

**Regras de negócio** (`documentacao.html`, "Para validar antes de enviar", e painel do `prototipo-v2.html`):

- Os dias qualificados são seguidos? Se o licenciado perder a qualificação, a contagem zera?
- Bater 90 dias é requisito pra subir de graduação? As duas propostas assumem que sim, por uma pista no código do escritório virtual.
- Quais são os requisitos e as metas oficiais pra Executivo? Os números do protótipo são de exemplo.
- PRO 360 é ter as 3 verticais PRO e 2 conexões Expansão? É a leitura do print do web.
- O app tem o histórico de PRO por vertical dos meses fechados?

**Produto** (`documentacao.html`):

- V2: o nome da tela fica "Minha jornada" ou continua "Histórico de Green Points"?
- Cada graduação terá a sua cor no card da prévia? Hoje só o Gestor está desenhado.

**Pra testar com licenciados** (`documentacao.html` e `prototipo-v2.html`):

- Com tudo numa tela, ela fica longa. Os 4 números do topo e os atalhos bastam pra navegar?
- Teste moderado com 5 licenciados por proposta já mostra os tropeços maiores.

**Da proposta "Minha jornada" do Figma que toca a V2** (`prototipo-jornada.html` e `documentacao-jornada.html`):

- Meta dos dias qualificados: o Figma mostra "3 de 10", e o escritório virtual mostra meta de 90 dias. Qual vale? A meta muda por graduação?
- "Ver toda jornada", na home, leva pra tela de jornada do Figma ou pro Histórico de Green Points? O pedido original falava em "Consultar Histórico".
- Nome repetido: na V2, o painel também se chama "Minha jornada". Um dos dois precisa de outro nome.
- "Rumo a Executivo" repete a lista de requisitos da jornada do Figma. Sugestão de lá: aqui fica um link "Ver minha jornada", e a jornada vira a fonte completa.

**Lacunas deste pacote, a confirmar** (o protótipo não define):

- Cor do card da home e do topo da jornada pra outras graduações. Só o Gestor (laranja) existe. O verde do Sênior é sugestão, só pro card da prévia.
- O selo real de cada graduação. O "G" no círculo é ilustrativo.
- Texto do painel de Green Points e da opção "Fechar na faixa Elite" quando o mês já passou de 2.000 GP. O protótipo só desenha o caso abaixo da meta.
- Escala do gráfico: o protótipo usa 2.400 GP fixos.
- A lista do histórico mostra 5 meses e o gráfico mostra 6, como no protótipo. É intencional?
- Aba "Acumulado" do histórico: o protótipo diz que ela não muda nesta proposta. O comportamento atual vale.

## Nome da tela: atenção

O painel da V2 se chama "Minha jornada". Já existe no Figma uma tela com esse nome: o histórico de graduações, redesenhado em `../prototipo-jornada.html`. Os dois não podem ter o mesmo nome. O nome final está pendente. Até lá, trate "Minha jornada" como provisório, inclusive no nome da rota e do componente.
