---
type: sandbox
title: Handoff RN da V2 do card de Reconhecimento
created: 2026-10-20
updated: 2026-10-20
status: active
tags: [igreen, app-licenciado, handoff, react-native]
---

# Handoff RN · Reconhecimento V2

Pacote para os desenvolvedores converterem a Versão 2 aprovada do card de Reconhecimento e da tela "Minha jornada" para React Native. Reorganiza o desenho do `../prototipo-v2.html` em componentes, tokens e tipos, sem mudar o visual.

## Artefatos desta pasta

| Arquivo | O que é |
|---|---|
| `index.html` | Todas as telas e estados da V2 lado a lado em 360 px, e PRO por vertical em 320 px, montados só com flexbox e marcados com a primitiva e o componente RN de cada elemento |
| `HANDOFF.md` | Guia para o desenvolvedor: telas e estados, inventário de componentes, bibliotecas, paralaxe do topo, regras de 320 px, acessibilidade, diferenças e pendências de negócio |
| `theme.ts` | Tokens do protótipo (cores, espaçamento, raios, tipografia, degradês, sombras), com a linha de origem de cada valor |
| `tipos.ts` | Contrato de dados das telas e `dadosExemplo` com os números do protótipo, marcando o que é exemplo e o que falta confirmar |
| `README.md` | Este arquivo |
