/**
 * theme.ts — tokens da V2 do card de Reconhecimento (app do licenciado iGreen).
 *
 * Fonte de todos os valores: ../prototipo-v2.html.
 * "l.NN" no comentário = linha do prototipo-v2.html de onde o valor saiu.
 *
 * Regra de nome: a chave aqui é o nome da variável CSS no index.html.
 *   colors.colorPrimary  ↔  var(--colorPrimary)
 *   spacing.space16      ↔  var(--space16)
 *   radius.radius20      ↔  var(--radius20)
 *   typography.typeCardLevel ↔ font: var(--typeCardLevel)
 *   gradients.gradientRecognitionCard ↔ background-image: var(--gradientRecognitionCard)
 *
 * Só a versão clara. Esta proposta não tem modo escuro.
 * Nenhum valor foi normalizado: a escala é a que o protótipo usa, com os
 * números quebrados (9, 7, 12,5) que ele tem. Arredondar muda o visual.
 */

/* ------------------------------------------------------------------ */
/* Cores                                                               */
/* ------------------------------------------------------------------ */
export const colors = {
  // Base do app — bloco :root (l.15–19)
  colorAppBg: '#EFF1F2', // --app-bg (l.15): fundo das telas
  colorSurface: '#FFFFFF', // --surface (l.15): cards brancos, sheet, barra de atalhos
  colorWhite: '#FFFFFF', // texto e ícones sobre fundo escuro (.rec, .dash-top, .money: color #fff)
  colorBlack: '#000000', // véu do topo que escurece na rolagem (.dash-top::after, l.146)
  colorInk: '#0D0F0F', // --ink (l.15): texto principal; miolo do selo (l.755)
  colorMuted: '#6A6E71', // --muted (l.15): texto secundário; ícone de info (l.738)
  colorLine: '#ECEEEF', // --line (l.15): bordas e divisórias
  colorSoft: '#F1F2F3', // --soft (l.15): fundos neutros (regra da faixa, infobar, atalhos)
  colorPrimary: '#338449', // --primary (l.16)
  colorAccent: '#EBF3ED', // --accent (l.16): fundo verde claro (selos "up", halo do mês atual)
  colorLime: '#B6E36B', // --lime (l.17): destaque sobre fundo escuro
  colorGold: '#E7A84B', // --gold (l.17): percentual da Elite no painel de GP do card
  colorBase: '#22A45A', // --base (l.17): faixa Base (barras, gráfico, selo do mês)
  colorElite: '#E8890C', // --elite (l.17): faixa Elite
  colorWarnInk: '#A75A05', // --warn-ink (l.17)
  colorWarnBg: '#FFF4E5', // --warn-bg (l.17)

  // Verticais — origem dos pontos (l.18)
  colorEnergia: '#22A45A',
  colorTelecom: '#3BA6DA',
  colorSeguros: '#A070DB',
  colorExpansao: '#E39A2D',

  // Ícone em círculo por vertical, fundo e traço (.lic.*, l.309–312)
  colorIconEnergiaBg: '#E6F5EC',
  colorIconEnergiaFg: '#1E8F4E',
  colorIconTelecomBg: '#E4F2FA',
  colorIconTelecomFg: '#2484B8',
  colorIconSegurosBg: '#F0EAFB',
  colorIconSegurosFg: '#7E52D0',
  colorIconExpansaoBg: '#FCEFDD',
  colorIconExpansaoFg: '#BD7210',

  // Graduação
  colorGestor: '#F29A1F', // cor do selo do Gestor: badge('#F29A1F') (l.781, 821, 856, 1046). Outras graduações: a confirmar

  // Cores soltas no CSS do protótipo
  colorWarnOnDark: '#FFC977', // aviso e Elite sobre o card escuro da prévia (l.260, 267, 272)
  colorProgressTrack: '#DFE2E4', // trilho das barras claras (.mbar, l.285)
  colorGaugeTrack: '#E6E9EB', // trilho da meia-lua (l.839)
  colorGaugeStart: '#9FDCB2', // início do degradê da meia-lua (l.838)
  colorTimelineDot: '#C9CFD3', // bolinha do mês passado e borda das outras (l.227–228)
  colorCheckBorder: '#CDD2D5', // círculo do requisito não cumprido (l.351)
  colorTabsBg: '#EEF0F1', // fundo das abas (l.322)
  colorSheetHandle: '#D6DADC', // alça do sheet (l.411)
  colorCircleBorder: '#D9DDE0', // botões redondos do sheet (l.417)
  colorTextDim: '#A9AEB1', // faixa que não vale no mês (l.434)
  colorEliteDim: '#F2C287', // 0,8% quando o mês não é Elite (l.1018)
  colorChartThreshold: '#1E2422', // linha e etiqueta "Elite" do gráfico (l.382–383)
  colorChartAxis: '#9AA0A4', // meses do eixo do gráfico (l.387)
  colorChartCurrent: '#2DAA5F', // barra do mês atual, listra e contorno (l.386)
  colorChartCurrentStripe: '#8BD3A6', // segunda listra da barra do mês atual (l.386)
  colorInsetOkBorder: '#CFE5D6', // borda do aviso verde (l.298)
  colorInsetPlainBorder: '#E6E8EA', // borda do aviso neutro (l.299)
  colorShortcutBarBorder: '#E6E9EB', // linha de baixo da barra de atalhos (box-shadow 0 1px 0, l.151)
  colorTabBarBorder: '#E3E6E8', // borda da tab bar (contexto, l.85)
  colorStubBorder: '#C9CED1', // borda tracejada do bloco "Meu saldo" (contexto, l.84)

  // Transparências sobre fundo escuro (branco com alfa)
  colorWhiteA05: 'rgba(255,255,255,0.05)', // grade do topo da jornada (l.141)
  colorWhiteA06: 'rgba(255,255,255,0.06)', // fim do degradê do aviso da prévia (l.256)
  colorWhiteA07: 'rgba(255,255,255,0.07)', // grade do card da prévia (l.246)
  colorWhiteA08: 'rgba(255,255,255,0.08)', // fundo dos 4 números (l.177); borda do painel de GP (l.117)
  colorWhiteA09: 'rgba(255,255,255,0.09)', // grade do card da home (l.95); borda do aviso da prévia (l.256)
  colorWhiteA10: 'rgba(255,255,255,0.10)', // divisória das linhas no card da prévia (l.264)
  colorWhiteA12: 'rgba(255,255,255,0.12)', // pílula do painel de GP (l.128); borda dos 4 números (l.177); ícones no card da prévia (l.266)
  colorWhiteA14: 'rgba(255,255,255,0.14)', // separador do card da prévia (l.262)
  colorWhiteA18: 'rgba(255,255,255,0.18)', // trilho da barra no card da prévia (l.271)
  colorWhiteA22: 'rgba(255,255,255,0.22)', // trilho das barras no card e no topo (l.115)
  colorWhiteA25: 'rgba(255,255,255,0.25)', // borda do avatar (contexto, l.71)
  colorWhiteA28: 'rgba(255,255,255,0.28)', // trilho do anel do card (l.786)
  colorWhiteA68: 'rgba(255,255,255,0.68)', // detalhe das linhas no card da prévia (l.270)
  colorWhiteA90: 'rgba(255,255,255,0.90)', // texto do aviso da prévia (l.255)
  colorCardPanel: 'rgba(48,32,24,0.6)', // painel de Green Points dentro do card (l.117)
  colorScrim: 'rgba(13,15,15,0.55)', // fundo escurecido atrás do sheet (l.405)
} as const;

/* ------------------------------------------------------------------ */
/* Espaçamento (padding, margin, gap). Valores em px/dp                 */
/* ------------------------------------------------------------------ */
export const spacing = {
  space2: 2,
  space3: 3, // padding vertical do selo "ao vivo" e das abas (l.281, l.322)
  space4: 4,
  space5: 5, // gap do selo "ao vivo" e do rótulo "Prévia" (l.104, l.281)
  space6: 6,
  space7: 7, // margem da barra nos 4 números (l.182)
  space8: 8,
  space9: 9, // padding do aviso da prévia e dos selos (l.255, l.277)
  space10: 10,
  space12: 12,
  space14: 14,
  space16: 16,
  space18: 18,
  space20: 20, // padding lateral do corpo em 320 px (l.447)
  space22: 22, // bloco "Meu saldo" (contexto, l.84)
  space24: 24, // padding lateral do corpo em 360 px (l.79, l.184)
  space26: 26, // barra de status (contexto, l.65)
  space28: 28,
  space32: 32,
  space40: 40, // fim do topo da home (contexto, l.69)
  space44: 44, // fim do topo da jornada (l.136)
} as const;

/* ------------------------------------------------------------------ */
/* Raios                                                               */
/* ------------------------------------------------------------------ */
export const radius = {
  radius4: 4, // base das barras do gráfico (l.384)
  radius5: 5, // etiqueta "Elite" do gráfico (l.383)
  radius8: 8, // aba selecionada (l.323); topo das barras do gráfico (l.384)
  radius10: 10, // abas (l.322); pílula do painel de GP (l.128); infobar (l.435)
  radius12: 12, // regra da faixa (l.236); aviso da prévia (l.255); avisos (l.294)
  radius14: 14, // 4 números do topo (l.177)
  radius16: 16, // painel de GP do card (l.117)
  radius20: 20, // cards brancos (.box, l.275) e card da prévia (l.243)
  radius24: 24, // card da home (l.90); topo do corpo (l.184); topo do sheet (l.407)
  radiusPill: 999, // pílulas, círculos e barras (99px, 9px e 50% no protótipo dão o mesmo desenho)
} as const;

/* ------------------------------------------------------------------ */
/* Tipografia — Outfit (l.9 e l.20)                                     */
/* ------------------------------------------------------------------ */
/**
 * No RN, cada peso da Outfit é uma família própria (@expo-google-fonts/outfit).
 * fontWeight fica junto pra quem usar fonte do sistema como reserva.
 * lineHeight: onde o protótipo usa "normal", o valor é a altura medida da
 * Outfit no navegador (≈ 1,26 × tamanho), arredondada.
 */
export const fonts = {
  regular: 'Outfit_400Regular',
  medium: 'Outfit_500Medium',
  semiBold: 'Outfit_600SemiBold',
  bold: 'Outfit_700Bold',
} as const;

export type TextToken = {
  fontFamily: string;
  fontWeight: '400' | '500' | '600' | '700';
  fontSize?: number; // ausente = herda do Text pai (só nos estilos "Inline")
  lineHeight?: number; // ausente = herda do Text pai
};

export const typography = {
  // Contexto: barra de status, topo da home e tab bar (não mudam nesta proposta)
  typeStatusBar: { fontFamily: 'Outfit_600SemiBold', fontWeight: '600', fontSize: 15, lineHeight: 19 }, // l.65
  typeTabBarLabel: { fontFamily: 'Outfit_400Regular', fontWeight: '400', fontSize: 10.5, lineHeight: 14 }, // l.86
  typeTabBarLabelActive: { fontFamily: 'Outfit_600SemiBold', fontWeight: '600', fontSize: 10.5, lineHeight: 14 }, // l.87
  typeHomeName: { fontFamily: 'Outfit_600SemiBold', fontWeight: '600', fontSize: 14, lineHeight: 18 }, // l.73
  typeHomeMeta: { fontFamily: 'Outfit_400Regular', fontWeight: '400', fontSize: 12, lineHeight: 15 }, // l.74–75
  typeHomeMetaStrong: { fontFamily: 'Outfit_600SemiBold', fontWeight: '600', fontSize: 12, lineHeight: 15 }, // l.76
  typeStub: { fontFamily: 'Outfit_400Regular', fontWeight: '400', fontSize: 13, lineHeight: 16 }, // l.84

  // Home: título da seção e link
  typeSectionHeader: { fontFamily: 'Outfit_600SemiBold', fontWeight: '600', fontSize: 16, lineHeight: 20 }, // l.81
  typeLink: { fontFamily: 'Outfit_600SemiBold', fontWeight: '600', fontSize: 14, lineHeight: 18 }, // l.82

  // RecognitionCard (l.100–128)
  typeCardLevel: { fontFamily: 'Outfit_600SemiBold', fontWeight: '600', fontSize: 20, lineHeight: 24 }, // l.100
  typeCardValue: { fontFamily: 'Outfit_600SemiBold', fontWeight: '600', fontSize: 14, lineHeight: 18 }, // kWh, Prévia, meta, % do anel (l.101, 105, 110)
  typeCardUnit: { fontFamily: 'Outfit_400Regular', fontWeight: '400', fontSize: 12, lineHeight: 15 }, // "kWh" ao lado do valor (l.102, 106)
  typeCardLabel: { fontFamily: 'Outfit_400Regular', fontWeight: '400', fontSize: 13, lineHeight: 16 }, // "Prévia", "Executivo" (l.104)
  typeDaysRow: { fontFamily: 'Outfit_400Regular', fontWeight: '400', fontSize: 13, lineHeight: 18 }, // l.111
  typeDaysRowStrong: { fontFamily: 'Outfit_600SemiBold', fontWeight: '600', fontSize: 13, lineHeight: 18 }, // l.113
  typeGpLabel: { fontFamily: 'Outfit_400Regular', fontWeight: '400', fontSize: 12, lineHeight: 16 }, // l.121
  typeGpValue: { fontFamily: 'Outfit_600SemiBold', fontWeight: '600', fontSize: 22, lineHeight: 28 }, // l.123
  typeGpRate: { fontFamily: 'Outfit_600SemiBold', fontWeight: '600', fontSize: 18, lineHeight: 28 }, // l.124
  typeBandLegend: { fontFamily: 'Outfit_400Regular', fontWeight: '400', fontSize: 12, lineHeight: 14 }, // l.126
  typeBandLegendStrong: { fontFamily: 'Outfit_600SemiBold', fontWeight: '600', fontSize: 12, lineHeight: 14 }, // l.127
  typePill: { fontFamily: 'Outfit_400Regular', fontWeight: '400', fontSize: 13, lineHeight: 16 }, // l.128

  // JourneyHeader e KpiTile (l.165–182)
  typeHeaderTitle: { fontFamily: 'Outfit_500Medium', fontWeight: '500', fontSize: 16, lineHeight: 20 }, // l.167
  typeLevelName: { fontFamily: 'Outfit_600SemiBold', fontWeight: '600', fontSize: 22, lineHeight: 26 }, // l.170
  typeLevelSub: { fontFamily: 'Outfit_400Regular', fontWeight: '400', fontSize: 13, lineHeight: 16 }, // l.171
  typeProgressMeta: { fontFamily: 'Outfit_400Regular', fontWeight: '400', fontSize: 12, lineHeight: 15 }, // l.174
  typeKpiLabel: { fontFamily: 'Outfit_400Regular', fontWeight: '400', fontSize: 12, lineHeight: 16 }, // l.178
  typeKpiValue: { fontFamily: 'Outfit_600SemiBold', fontWeight: '600', fontSize: 17, lineHeight: 22 }, // l.179
  typeKpiUnit: { fontFamily: 'Outfit_400Regular', fontWeight: '400', fontSize: 12, lineHeight: 15 }, // l.180

  // Corpo da jornada
  typeSectionTitle: { fontFamily: 'Outfit_600SemiBold', fontWeight: '600', fontSize: 17, lineHeight: 24 }, // .dsec-h h4 (l.187) e .sec > h4 do sheet (l.419)
  typeFootnote: { fontFamily: 'Outfit_400Regular', fontWeight: '400', fontSize: 12, lineHeight: 18 }, // l.402
  typeLiveBadge: { fontFamily: 'Outfit_600SemiBold', fontWeight: '600', fontSize: 11.5, lineHeight: 15 }, // l.281
  typeBadge: { fontFamily: 'Outfit_600SemiBold', fontWeight: '600', fontSize: 12, lineHeight: 15 }, // .chip (l.277)
  typeBadgeSmall: { fontFamily: 'Outfit_600SemiBold', fontWeight: '600', fontSize: 11, lineHeight: 15 }, // .l1 .chip (l.314)
  typeTab: { fontFamily: 'Outfit_400Regular', fontWeight: '400', fontSize: 14, lineHeight: 18 }, // l.323

  // BandTimeline (l.231–236)
  typeTimelineMonth: { fontFamily: 'Outfit_400Regular', fontWeight: '400', fontSize: 12, lineHeight: 16 },
  typeTimelineMonthNow: { fontFamily: 'Outfit_600SemiBold', fontWeight: '600', fontSize: 12, lineHeight: 16 },
  typeTimelineValue: { fontFamily: 'Outfit_600SemiBold', fontWeight: '600', fontSize: 16, lineHeight: 20 },
  typeCaption: { fontFamily: 'Outfit_400Regular', fontWeight: '400', fontSize: 12, lineHeight: 16 }, // .cap (l.190)
  typeRule: { fontFamily: 'Outfit_400Regular', fontWeight: '400', fontSize: 12.5, lineHeight: 17 },

  // PreviewCard (l.249–272)
  typePreviewLabel: { fontFamily: 'Outfit_400Regular', fontWeight: '400', fontSize: 12, lineHeight: 20 }, // CSS diz 16, mas a linha fica 20 no protótipo (span inline num bloco de 16 px). 20 reproduz o desenho
  typePreviewValue: { fontFamily: 'Outfit_600SemiBold', fontWeight: '600', fontSize: 28, lineHeight: 34 }, // l.251
  typePreviewElite: { fontFamily: 'Outfit_600SemiBold', fontWeight: '600', fontSize: 15, lineHeight: 20 }, // l.253
  typeStatus: { fontFamily: 'Outfit_500Medium', fontWeight: '500', fontSize: 12.5, lineHeight: 17 }, // l.255
  typePreviewHeading: { fontFamily: 'Outfit_600SemiBold', fontWeight: '600', fontSize: 14, lineHeight: 20 }, // l.263

  // Linhas de lista (.lrow, l.302–320)
  typeRowTitle: { fontFamily: 'Outfit_500Medium', fontWeight: '500', fontSize: 15, lineHeight: 20 }, // .l1
  typeRowAmount: { fontFamily: 'Outfit_600SemiBold', fontWeight: '600', fontSize: 15, lineHeight: 20 }, // .amt
  typeRowDetail: { fontFamily: 'Outfit_400Regular', fontWeight: '400', fontSize: 12.5, lineHeight: 17 }, // .l2 no card da prévia
  typeRowDetailList: { fontFamily: 'Outfit_400Regular', fontWeight: '400', fontSize: 12.5, lineHeight: 18 }, // .vlist .l2 (l.330)
  typeRowNote: { fontFamily: 'Outfit_400Regular', fontWeight: '400', fontSize: 12, lineHeight: 18 }, // .vlist .amt2 (l.330)
  typeTabsCaption: { fontFamily: 'Outfit_400Regular', fontWeight: '400', fontSize: 12.5, lineHeight: 16 }, // .vcap (l.326)
  typeDisclosure: { fontFamily: 'Outfit_500Medium', fontWeight: '500', fontSize: 13, lineHeight: 16 }, // summary (l.333)
  typeDisclosureBody: { fontFamily: 'Outfit_400Regular', fontWeight: '400', fontSize: 13, lineHeight: 19.5 }, // l.336

  // DaysGauge e RequirementRow (l.339–374)
  typeGaugeValue: { fontFamily: 'Outfit_600SemiBold', fontWeight: '600', fontSize: 36, lineHeight: 40 }, // l.361
  typeGaugeUnit: { fontFamily: 'Outfit_400Regular', fontWeight: '400', fontSize: 12.5, lineHeight: 16 }, // l.362
  typeGaugeScale: { fontFamily: 'Outfit_400Regular', fontWeight: '400', fontSize: 11, lineHeight: 14 }, // l.363
  typeGaugeTitle: { fontFamily: 'Outfit_600SemiBold', fontWeight: '600', fontSize: 16, lineHeight: 22 }, // l.366
  typeGoalTag: { fontFamily: 'Outfit_600SemiBold', fontWeight: '600', fontSize: 12, lineHeight: 16 }, // l.347
  typeGaugeSub: { fontFamily: 'Outfit_400Regular', fontWeight: '400', fontSize: 12.5, lineHeight: 17 }, // l.368
  typeFraction: { fontFamily: 'Outfit_600SemiBold', fontWeight: '600', fontSize: 15, lineHeight: 19 }, // l.354
  typeRequirementLabel: { fontFamily: 'Outfit_400Regular', fontWeight: '400', fontSize: 14, lineHeight: 18 }, // l.371
  typeRequirementValue: { fontFamily: 'Outfit_400Regular', fontWeight: '400', fontSize: 13, lineHeight: 16 }, // l.372

  // HistoryChart e MonthRow (l.379–401)
  typeChartTitle: { fontFamily: 'Outfit_600SemiBold', fontWeight: '600', fontSize: 18, lineHeight: 23 }, // l.379
  typeChartAxis: { fontFamily: 'Outfit_400Regular', fontWeight: '400', fontSize: 12, lineHeight: 15 }, // l.387
  typeChartAxisCurrent: { fontFamily: 'Outfit_600SemiBold', fontWeight: '600', fontSize: 12, lineHeight: 15 }, // l.388
  typeChartTag: { fontFamily: 'Outfit_400Regular', fontWeight: '400', fontSize: 11, lineHeight: 14 }, // l.383
  typeLegend: { fontFamily: 'Outfit_400Regular', fontWeight: '400', fontSize: 13, lineHeight: 16 }, // l.389
  typeMonthRowTitle: { fontFamily: 'Outfit_600SemiBold', fontWeight: '600', fontSize: 15, lineHeight: 20 }, // l.396
  typeMonthRowYear: { fontFamily: 'Outfit_400Regular', fontWeight: '400', fontSize: 16, lineHeight: 20 }, // "/ 2026" herda 16 px do botão (l.397)
  typeMonthRowSub: { fontFamily: 'Outfit_400Regular', fontWeight: '400', fontSize: 13, lineHeight: 16 }, // l.398
  typeMonthRowValue: { fontFamily: 'Outfit_600SemiBold', fontWeight: '600', fontSize: 15, lineHeight: 19 }, // l.401
  typeMonthRowRate: { fontFamily: 'Outfit_400Regular', fontWeight: '400', fontSize: 13, lineHeight: 16 }, // l.400

  // ShortcutBar e Chip (l.157–164)
  typeBarTitle: { fontFamily: 'Outfit_600SemiBold', fontWeight: '600', fontSize: 16, lineHeight: 20 }, // l.158
  typeBarSub: { fontFamily: 'Outfit_400Regular', fontWeight: '400', fontSize: 12, lineHeight: 20 }, // l.159 (linha 20 pelo mesmo motivo de typePreviewLabel)
  typeChip: { fontFamily: 'Outfit_500Medium', fontWeight: '500', fontSize: 13, lineHeight: 18 }, // l.163

  // MonthSheet (l.415–440)
  typeSheetTitle: { fontFamily: 'Outfit_600SemiBold', fontWeight: '600', fontSize: 20, lineHeight: 24 }, // l.415
  typeMonthHeadTitle: { fontFamily: 'Outfit_600SemiBold', fontWeight: '600', fontSize: 17, lineHeight: 20 }, // l.423
  typeMonthHeadSub: { fontFamily: 'Outfit_400Regular', fontWeight: '400', fontSize: 13, lineHeight: 20 }, // l.424 (linha 20, span inline)
  typeMonthHeadLabel: { fontFamily: 'Outfit_400Regular', fontWeight: '400', fontSize: 13, lineHeight: 18 }, // l.425
  typeMonthHeadValue: { fontFamily: 'Outfit_600SemiBold', fontWeight: '600', fontSize: 16, lineHeight: 18 }, // l.426
  typeMonthGpLabel: { fontFamily: 'Outfit_400Regular', fontWeight: '400', fontSize: 13, lineHeight: 20 }, // .k (l.276), linha 20 (span inline)
  typeMonthGpValue: { fontFamily: 'Outfit_600SemiBold', fontWeight: '600', fontSize: 30, lineHeight: 34 }, // l.429
  typeMonthGpUnit: { fontFamily: 'Outfit_500Medium', fontWeight: '500', fontSize: 15, lineHeight: 19 }, // l.430
  typeBandLegend13: { fontFamily: 'Outfit_400Regular', fontWeight: '400', fontSize: 13, lineHeight: 16 }, // l.432
  typeBandLegend13Strong: { fontFamily: 'Outfit_600SemiBold', fontWeight: '600', fontSize: 13, lineHeight: 16 }, // l.433
  typeInfo: { fontFamily: 'Outfit_400Regular', fontWeight: '400', fontSize: 13, lineHeight: 18 }, // .infobar e .inset (l.294, l.435)
  typeOrigin: { fontFamily: 'Outfit_400Regular', fontWeight: '400', fontSize: 14, lineHeight: 18 }, // l.439
  typeOriginValue: { fontFamily: 'Outfit_600SemiBold', fontWeight: '600', fontSize: 14, lineHeight: 18 }, // l.440

  // Aninhados: Text dentro de Text, mesmo tamanho do pai, só muda o peso
  typeInlineSemiBold: { fontFamily: 'Outfit_600SemiBold', fontWeight: '600' }, // <b> com font-weight 600
  typeInlineBold: { fontFamily: 'Outfit_700Bold', fontWeight: '700' }, // <b> sem regra (pílula do painel) e fração de requisitos (l.369)
} as const satisfies Record<string, TextToken>;

/* ------------------------------------------------------------------ */
/* Degradês                                                            */
/* ------------------------------------------------------------------ */
/**
 * kind 'linear' → expo-linear-gradient: <LinearGradient colors locations start end />.
 *   cssAngle é só pro index.html (linear-gradient do CSS).
 * kind 'radial' → react-native-svg: <RadialGradient> dentro de um <Svg> do tamanho do card.
 *   O protótipo usa radial-gradient(Lx% Ly% at Cx% Cy%). Em SVG com unidades do
 *   próprio retângulo: cx = Cx, cy = Cy, r = Lx e gradientTransform scale(1, Ly/Lx).
 *   A última parada repete a cor anterior com opacidade 0: o protótipo escreve
 *   rgba(...,0) e o CSS mistura com alfa pré-multiplicado, o SVG não. Assim não escurece a borda.
 * kind 'stripes' → <Pattern> do react-native-svg.
 */
export const gradients = {
  // Card da home (.rec, l.91–93). Gestor. Outras graduações: a confirmar
  gradientRecognitionCard: {
    kind: 'linear',
    colors: ['#C9772C', '#8F4C1E', '#4A2614', '#24150F'],
    locations: [0, 0.32, 0.58, 1],
    start: { x: 0, y: 0 },
    end: { x: 0, y: 1 },
    cssAngle: 180,
  },
  // Brilho do card: radial-gradient(90% 42% at 50% 0%, rgba(255,206,110,.95) 0%, rgba(236,150,52,.85) 35%, rgba(170,88,30,0) 78%) (l.92)
  gradientRecognitionCardGlow: {
    kind: 'radial',
    cx: 0.5,
    cy: 0,
    r: 0.9,
    scaleY: 0.4667, // 42 / 90
    stops: [
      { offset: 0, color: '#FFCE6E', opacity: 0.95 },
      { offset: 0.35, color: '#EC9634', opacity: 0.85 },
      { offset: 0.78, color: '#EC9634', opacity: 0 },
    ],
  },

  // Topo da Minha jornada (.dash-top, l.137–139). Gestor. Outras graduações: a confirmar
  gradientJourneyHeader: {
    kind: 'linear',
    colors: ['#2B1A10', '#150D08'],
    locations: [0, 1],
    start: { x: 0, y: 0 },
    end: { x: 0, y: 1 },
    cssAngle: 180,
  },
  // radial-gradient(85% 55% at 88% 0%, rgba(242,154,31,.5) 0%, rgba(242,154,31,0) 70%) (l.138)
  gradientJourneyHeaderGlow: {
    kind: 'radial',
    cx: 0.88,
    cy: 0,
    r: 0.85,
    scaleY: 0.6471, // 55 / 85
    stops: [
      { offset: 0, color: '#F29A1F', opacity: 0.5 },
      { offset: 0.7, color: '#F29A1F', opacity: 0 },
    ],
  },

  // Card "Sua prévia" — fundo por graduação (l.239–244)
  // Gestor: --lv-1 #5C3016, --lv-2 #2C1A10, --lv-3 #18100A, --lv-glow rgba(242,154,31,.42) (l.242)
  gradientPreviewGestor: {
    kind: 'linear',
    colors: ['#5C3016', '#2C1A10', '#18100A'],
    locations: [0, 0.32, 1],
    start: { x: 0, y: 0 },
    end: { x: 0, y: 1 },
    cssAngle: 180,
  },
  // radial-gradient(75% 38% at 90% 0%, var(--lv-glow) 0%, rgba(0,0,0,0) 72%) (l.244)
  gradientPreviewGestorGlow: {
    kind: 'radial',
    cx: 0.9,
    cy: 0,
    r: 0.75,
    scaleY: 0.5067, // 38 / 75
    stops: [
      { offset: 0, color: '#F29A1F', opacity: 0.42 },
      { offset: 0.72, color: '#F29A1F', opacity: 0 },
    ],
  },
  // Sênior: VALOR SUGERIDO, está só como comentário no protótipo (l.240–241):
  // --lv-1:#1F6B43; --lv-2:#13432B; --lv-3:#0C2418; --lv-glow:rgba(120,230,160,.45)
  // Nenhuma tela usa. Cor das outras graduações: a confirmar
  gradientPreviewSenior: {
    kind: 'linear',
    colors: ['#1F6B43', '#13432B', '#0C2418'],
    locations: [0, 0.32, 1],
    start: { x: 0, y: 0 },
    end: { x: 0, y: 1 },
    cssAngle: 180,
  },
  gradientPreviewSeniorGlow: {
    kind: 'radial',
    cx: 0.9,
    cy: 0,
    r: 0.75,
    scaleY: 0.5067,
    stops: [
      { offset: 0, color: '#78E6A0', opacity: 0.45 },
      { offset: 0.72, color: '#78E6A0', opacity: 0 },
    ],
  },

  // Aviso "Reduzida / Cheia" dentro do card da prévia (l.256)
  gradientPreviewStatus: {
    kind: 'linear',
    colors: ['rgba(255,255,255,0.12)', 'rgba(255,255,255,0.06)'],
    locations: [0, 1],
    start: { x: 0, y: 0 },
    end: { x: 0, y: 1 },
    cssAngle: 180,
  },

  // Meia-lua dos dias qualificados: linearGradient horizontal dentro do Svg (l.838)
  gradientGauge: {
    kind: 'linear',
    colors: ['#9FDCB2', '#338449'],
    locations: [0, 1],
    start: { x: 0, y: 0 },
    end: { x: 1, y: 0 },
    cssAngle: 90,
  },

  // Barra do mês atual no gráfico: repeating-linear-gradient(135deg, #2DAA5F 0 5px, #8BD3A6 5px 9px) (l.386)
  patternChartCurrent: {
    kind: 'stripes',
    colors: ['#2DAA5F', '#8BD3A6'],
    widths: [5, 4], // px de cada listra; o ciclo tem 9 px
    angle: 135,
  },

  // Contexto (não muda nesta proposta): topo da home e avatar
  // radial-gradient(120% 90% at 20% 0%, #1F4A31 0%, #12291C 60%, #0E2016 100%) (l.69)
  gradientHomeHeader: {
    kind: 'radial',
    cx: 0.2,
    cy: 0,
    r: 1.2,
    scaleY: 0.75, // 90 / 120
    stops: [
      { offset: 0, color: '#1F4A31', opacity: 1 },
      { offset: 0.6, color: '#12291C', opacity: 1 },
      { offset: 1, color: '#0E2016', opacity: 1 },
    ],
  },
  // linear-gradient(135deg, #55605B, #1E2422) (l.71)
  gradientAvatar: {
    kind: 'linear',
    colors: ['#55605B', '#1E2422'],
    locations: [0, 1],
    start: { x: 0, y: 0 },
    end: { x: 1, y: 1 },
    cssAngle: 135,
  },
} as const;

/** Fundo do card da prévia por graduação. Só o Gestor está desenhado. */
export const previewGradientByGraduation = {
  gestor: { base: gradients.gradientPreviewGestor, glow: gradients.gradientPreviewGestorGlow },
  senior: { base: gradients.gradientPreviewSenior, glow: gradients.gradientPreviewSeniorGlow }, // sugerido
} as const;

/* ------------------------------------------------------------------ */
/* Sombras (equivalente RN de cada box-shadow do protótipo)             */
/* ------------------------------------------------------------------ */
/**
 * O RN não tem "spread" (o -10px e o -12px do CSS). Os valores abaixo são
 * o ponto de partida; ajuste olhando no aparelho. elevation só desenha
 * sombra pra baixo no Android.
 */
export const shadows = {
  // Corpo da jornada sobre o topo: 0 -14px 30px -10px rgba(0,0,0,.5) (l.148)
  shadowJourneyBody: {
    shadowColor: '#000000',
    shadowOffset: { width: 0, height: -14 },
    shadowOpacity: 0.5,
    shadowRadius: 15,
    elevation: 0, // Android não faz sombra pra cima. Ver HANDOFF.md
  },
  // Barra branca de atalhos: 0 8px 18px -12px rgba(0,0,0,.28) (l.151)
  shadowShortcutBar: {
    shadowColor: '#000000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.28,
    shadowRadius: 9,
    elevation: 3,
  },
  // Aba selecionada: 0 1px 2px rgba(0,0,0,.1) (l.324)
  shadowTabSelected: {
    shadowColor: '#000000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 1,
    elevation: 1,
  },
} as const;

/* ------------------------------------------------------------------ */
/* Layout                                                              */
/* ------------------------------------------------------------------ */
export const layout = {
  referenceWidth: 360, // largura de referência do desenho
  compactMaxWidth: 340, // até aqui vale o layout de 320 px (@container max-width 340px, l.446)
  bodyPadding: 24, // padding lateral do corpo (l.79, l.184)
  bodyPaddingCompact: 20, // em 320 px (l.447)
  journeyHeaderHeight: 426, // altura medida do topo da jornada em 360 px, sem PRO e 62 dias
  shortcutBarHeight: 138, // altura medida da barra branca (com a barra de status de 44)
  sheetMaxHeight: 0.88, // 88% da altura da tela (l.407)
} as const;

export const theme = { colors, spacing, radius, fonts, typography, gradients, shadows, layout } as const;
export default theme;
