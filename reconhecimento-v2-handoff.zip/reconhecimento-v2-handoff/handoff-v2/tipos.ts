/**
 * tipos.ts — contrato de dados das telas da V2 do card de Reconhecimento.
 *
 * Fonte: ../prototipo-v2.html (PRESETS, ELITE_MIN, MESES, REQUISITOS, DIAS e
 * os textos fixos) e ../documentacao.html ("Para validar antes de enviar").
 *
 * Marcas nos comentários:
 *   EXEMPLO      → o número é de exemplo, igual ao protótipo. Vem da API.
 *   A CONFIRMAR  → regra ou dado ainda não validado. Lista em HANDOFF.md, "Pendências".
 *   DERIVADO     → o protótipo calcula na tela a partir de outros campos.
 *
 * Os nomes dos campos são sugestão. O que importa é o que cada tela precisa.
 * Valores em reais vêm como número (1362.25). A tela formata em pt-BR.
 */

/* ------------------------------------------------------------------ */
/* Básicos                                                             */
/* ------------------------------------------------------------------ */

/** Valor em reais, como número. Ex.: 1362.25 → "R$ 1.362,25". */
export type Reais = number;

/** Mês no formato 'AAAA-MM'. Ex.: '2026-10'. */
export type MonthKey = string;

/** As seis graduações, na ordem (documentacao-jornada.html, "Trilha das graduações"). */
export type GraduationId = 'consultor' | 'senior' | 'gestor' | 'executivo' | 'diretor' | 'acionista';

/** Faixa do mês. Define o percentual pago no mês seguinte. */
export type BandId = 'base' | 'elite';

/** Verticais que contam pro PRO. */
export type VerticalId = 'energia' | 'telecom' | 'seguros';

/** Origem dos pontos no detalhe do mês: as três verticais e a Expansão. */
export type PointsSourceId = VerticalId | 'expansao';

export interface Graduation {
  id: GraduationId;
  name: string; // "Gestor"
}

export interface MonthRef {
  key: MonthKey; // '2026-10'
  name: string; // 'Outubro'
  year: number; // 2026
}

/* ------------------------------------------------------------------ */
/* Licenciado e graduação                                              */
/* ------------------------------------------------------------------ */

/** Topo da home. Contexto: não muda nesta proposta. */
export interface Licensee {
  name: string; // EXEMPLO "Leandro Freire"
  licenseeId: string; // EXEMPLO "30393820"
  balance: Reais; // EXEMPLO 7600 → "Saldo: R$ 7.600,00"
}

/** Card da home e topo da jornada: graduação, kWh e meta da próxima. */
export interface GraduationProgress {
  current: Graduation; // EXEMPLO Gestor
  next: Graduation; // EXEMPLO Executivo
  kwh: number; // EXEMPLO 152340 kWh qualificáveis
  nextGoalKwh: number; // EXEMPLO 300000. A CONFIRMAR: meta oficial pra Executivo
  // DERIVADO: progresso = round(kwh / nextGoalKwh × 100) → 51%
  // DERIVADO: falta = nextGoalKwh − kwh → "Faltam 147.660 kWh para Executivo"
}

/** Dias qualificados: card, 4º número do topo e meia-lua. */
export interface QualifiedDays {
  days: number; // EXEMPLO 62 (em andamento) ou 195 (meta batida)
  goal: number; // EXEMPLO 90. A CONFIRMAR: o Figma mostra meta de 10; a meta muda por graduação?
  // A CONFIRMAR: os dias são seguidos? Zeram se a qualificação cair?
  //   A tela diz "Dias seguidos em que você se manteve qualificado como Gestor".
  // A CONFIRMAR: bater a meta é requisito pra subir de graduação? O protótipo assume que sim.
  // DERIVADO: meta batida = days >= goal. A tela troca "62/90" por "195 dias" com check.
}

/* ------------------------------------------------------------------ */
/* Faixa e Green Points                                                */
/* ------------------------------------------------------------------ */

/** Regras da faixa na graduação atual. */
export interface BandRules {
  eliteMinGp: number; // EXEMPLO 2000 GP no mês pra fechar na faixa Elite
  ratePct: Record<BandId, number>; // EXEMPLO { base: 0.6, elite: 0.8 } → "0,6%" e "0,8%"
  // Regra que a tela ensina: os GP de um mês definem a faixa do mês seguinte.
  // DERIVADO no protótipo: faixa = gp >= eliteMinGp ? 'elite' : 'base'.
}

/** Mês em andamento. */
export interface CurrentMonth extends MonthRef {
  asOfLabel: string; // EXEMPLO '20/10' → "Até 20/10" e "Outubro até 20/10"
  gp: number; // EXEMPLO 1240 GP gerados até agora
  band: BandId; // EXEMPLO 'base': faixa em vigor neste mês, definida pelos GP do mês anterior
  // DERIVADO: faixa do próximo mês "se fechar hoje" = gp >= eliteMinGp ? 'elite' : 'base'
  // DERIVADO: faltam pra Elite = eliteMinGp − gp → "Faltam 760 GP para Elite (0,8%)"
}

/* ------------------------------------------------------------------ */
/* Prévia e PRO                                                         */
/* ------------------------------------------------------------------ */

/** Card "Sua prévia" e 1º número do topo. */
export interface Preview {
  today: Reais; // EXEMPLO prévia de hoje: 1362.25 (sem PRO) ou 3482.90 (PRO garantido)
  full: Reais; // EXEMPLO prévia cheia, com PRO 360: 3482.90
  elite: Reais; // EXEMPLO Prévia Elite: 1418.90 (sem PRO) ou 3712.40 (PRO garantido)
  // DERIVADO: ganho por ser PRO 360 = full − today → "+R$ 2.120,65"
  // DERIVADO: ganho por fechar Elite = elite − today → "+R$ 56,65" ou "+R$ 229,50"
  // As formas de ganhar mais aparecem ordenadas pelo valor; a já garantida vai pro fim.
}

/** PRO 360 do mês anterior (define a prévia de hoje) e do atual (define o próximo pagamento). */
export interface Pro360Status {
  previousMonth: boolean; // foi PRO 360 no mês anterior → prévia "Cheia"; senão "Reduzida"
  currentMonth: boolean; // já bateu PRO 360 no mês atual → próximo mês "Garantido"
  verticalsPro: number; // EXEMPLO 0 ou 3 → "0 de 3 verticais"
  verticalsTotal: number; // EXEMPLO 3
  expansionConnections: number; // EXEMPLO 0 ou 2 → "0 de 2 Expansão" e "0/2"
  expansionGoal: number; // EXEMPLO 2
  // A CONFIRMAR: PRO 360 é ter as 3 verticais PRO e 2 conexões Expansão? É a leitura do print do web.
}

/** Uma linha de "PRO por vertical". */
export interface ProVertical {
  id: VerticalId;
  name: string; // "Energia"
  connectionsThisMonth: number; // EXEMPLO → "1 conexão este mês", "Sem conexão este mês"
  proPreviousMonth: boolean; // aba Hoje: "PRO" ou "Sem PRO" (pago agora, pelo PRO do mês anterior)
  proCurrentMonth: boolean; // aba Em Novembro: "PRO batido" ou "Falta bater"
  gp: Reais; // EXEMPLO prévia GP paga hoje
  network: Reais; // EXEMPLO prévia Rede paga hoje (GI, royalties e equiparação)
  gpFull: Reais; // EXEMPLO GP se for PRO
  networkFull: Reais; // EXEMPLO Rede se for PRO
  // DERIVADO aba Hoje: valor = gp + network; detalhe "GP R$ x · Rede R$ y"
  // DERIVADO aba Em Novembro: ganho = (gpFull − gp) + (networkFull − network) → "+R$ 1.747,25 se bater o PRO"
}

/* ------------------------------------------------------------------ */
/* Próxima graduação                                                   */
/* ------------------------------------------------------------------ */

/** Um requisito de "Rumo a Executivo". */
export interface Requirement {
  id: string;
  label: string; // "Licenciados diretos ativos"
  current: number; // EXEMPLO 8
  goal: number; // EXEMPLO 10. A CONFIRMAR: requisitos e metas oficiais pra Executivo
  // DERIVADO: cumprido = current >= goal
  // A fração do título soma os dias qualificados como mais um requisito: "1/5"
}

/* ------------------------------------------------------------------ */
/* Histórico                                                            */
/* ------------------------------------------------------------------ */

/** PRO de um mês fechado, pro sheet do mês. */
export interface MonthProStatus {
  pro360: boolean;
  verticals: { id: VerticalId; pro: boolean }[];
}

/** Um mês do gráfico, da lista e do sheet. */
export interface HistoryMonth extends MonthRef {
  short: string; // 'OUT' (eixo do gráfico)
  gp: number; // EXEMPLO
  band: BandId; // faixa que o mês fechou (ou fecharia hoje)
  inProgress: boolean; // mês atual: listrado no gráfico e "Em andamento"
  changeVsPreviousPct?: number; // EXEMPLO só mês fechado: 12 → "+12% vs ago"
  pointsBySource: Record<PointsSourceId, number>; // EXEMPLO origem dos pontos
  pro?: MonthProStatus; // só mês fechado. A CONFIRMAR: o app tem o histórico de PRO por vertical dos meses fechados?
  // O mês atual usa ProVertical.proCurrentMonth.
}

/* ------------------------------------------------------------------ */
/* Tudo que as telas da V2 precisam                                    */
/* ------------------------------------------------------------------ */

export interface RecognitionData {
  licensee: Licensee;
  graduation: GraduationProgress;
  qualifiedDays: QualifiedDays;
  bandRules: BandRules;
  currentMonth: CurrentMonth;
  nextMonth: MonthRef; // { '2026-11', 'Novembro' }: "Vale em Novembro", aba "Em Novembro"
  preview: Preview;
  pro360: Pro360Status;
  verticals: ProVertical[];
  requirements: Requirement[];
  history: HistoryMonth[]; // do mais antigo pro mais novo; o último é o mês atual. EXEMPLO 6 meses
  // O mês anterior ("Setembro 1.580 GP gerados" em Sua faixa) é o penúltimo do histórico.
}

/** Os cenários do protótipo. */
export interface DadosExemplo {
  semPro: RecognitionData; // cenário padrão: sem PRO 360, 62 de 90 dias
  proGarantido: RecognitionData; // mesmo licenciado com PRO 360 garantido
  diasMetaBatida: QualifiedDays; // troca só os dias: 195 de 90
}

/* ------------------------------------------------------------------ */
/* Dados de exemplo — os mesmos números do protótipo (EXEMPLO)          */
/* ------------------------------------------------------------------ */

const licensee: Licensee = { name: 'Leandro Freire', licenseeId: '30393820', balance: 7600 };

const graduation: GraduationProgress = {
  current: { id: 'gestor', name: 'Gestor' },
  next: { id: 'executivo', name: 'Executivo' },
  kwh: 152340,
  nextGoalKwh: 300000,
};

const bandRules: BandRules = { eliteMinGp: 2000, ratePct: { base: 0.6, elite: 0.8 } };

const currentMonth: CurrentMonth = {
  key: '2026-10',
  name: 'Outubro',
  year: 2026,
  asOfLabel: '20/10',
  gp: 1240,
  band: 'base',
};

const nextMonth: MonthRef = { key: '2026-11', name: 'Novembro', year: 2026 };

const requirements: Requirement[] = [
  { id: 'kwh', label: 'kWh qualificáveis', current: 152340, goal: 300000 },
  { id: 'diretos', label: 'Licenciados diretos ativos', current: 8, goal: 10 },
  { id: 'clientes', label: 'Clientes diretos', current: 24, goal: 20 },
  { id: 'gestores', label: 'Linhas de gestores', current: 1, goal: 2 },
];

/** Histórico de exemplo. `pro` dos meses fechados segue o protótipo, que repete o PRO do cenário. */
function history(pro: boolean): HistoryMonth[] {
  const closed = (): MonthProStatus => ({
    pro360: pro,
    verticals: [
      { id: 'energia', pro },
      { id: 'telecom', pro },
      { id: 'seguros', pro },
    ],
  });
  return [
    { key: '2026-05', name: 'Maio', year: 2026, short: 'MAI', gp: 1320, band: 'base', inProgress: false, changeVsPreviousPct: 8, pointsBySource: { energia: 900, telecom: 280, seguros: 90, expansao: 50 }, pro: closed() },
    { key: '2026-06', name: 'Junho', year: 2026, short: 'JUN', gp: 2140, band: 'elite', inProgress: false, changeVsPreviousPct: 62, pointsBySource: { energia: 1460, telecom: 420, seguros: 160, expansao: 100 }, pro: closed() },
    { key: '2026-07', name: 'Julho', year: 2026, short: 'JUL', gp: 1760, band: 'base', inProgress: false, changeVsPreviousPct: -18, pointsBySource: { energia: 1200, telecom: 350, seguros: 130, expansao: 80 }, pro: closed() },
    { key: '2026-08', name: 'Agosto', year: 2026, short: 'AGO', gp: 1410, band: 'base', inProgress: false, changeVsPreviousPct: -20, pointsBySource: { energia: 960, telecom: 300, seguros: 90, expansao: 60 }, pro: closed() },
    { key: '2026-09', name: 'Setembro', year: 2026, short: 'SET', gp: 1580, band: 'base', inProgress: false, changeVsPreviousPct: 12, pointsBySource: { energia: 1120, telecom: 310, seguros: 90, expansao: 60 }, pro: closed() },
    { key: '2026-10', name: 'Outubro', year: 2026, short: 'OUT', gp: 1240, band: 'base', inProgress: true, pointsBySource: { energia: 820, telecom: 260, seguros: 100, expansao: 60 } },
  ];
}

export const dadosExemplo: DadosExemplo = {
  semPro: {
    licensee,
    graduation,
    qualifiedDays: { days: 62, goal: 90 },
    bandRules,
    currentMonth,
    nextMonth,
    preview: { today: 1362.25, full: 3482.9, elite: 1418.9 },
    pro360: { previousMonth: false, currentMonth: false, verticalsPro: 0, verticalsTotal: 3, expansionConnections: 0, expansionGoal: 2 },
    verticals: [
      { id: 'energia', name: 'Energia', connectionsThisMonth: 1, proPreviousMonth: false, proCurrentMonth: false, gp: 1107.15, network: 0, gpFull: 2214.3, networkFull: 640.1 },
      { id: 'telecom', name: 'Telecom', connectionsThisMonth: 1, proPreviousMonth: false, proCurrentMonth: false, gp: 206.0, network: 0, gpFull: 412.0, networkFull: 96.4 },
      { id: 'seguros', name: 'Seguros', connectionsThisMonth: 0, proPreviousMonth: false, proCurrentMonth: false, gp: 49.1, network: 0, gpFull: 98.2, networkFull: 21.9 },
    ],
    requirements,
    history: history(false),
  },
  proGarantido: {
    licensee,
    graduation,
    qualifiedDays: { days: 62, goal: 90 },
    bandRules,
    currentMonth,
    nextMonth,
    preview: { today: 3482.9, full: 3482.9, elite: 3712.4 },
    pro360: { previousMonth: true, currentMonth: true, verticalsPro: 3, verticalsTotal: 3, expansionConnections: 2, expansionGoal: 2 },
    verticals: [
      { id: 'energia', name: 'Energia', connectionsThisMonth: 4, proPreviousMonth: true, proCurrentMonth: true, gp: 2214.3, network: 640.1, gpFull: 2214.3, networkFull: 640.1 },
      { id: 'telecom', name: 'Telecom', connectionsThisMonth: 2, proPreviousMonth: true, proCurrentMonth: true, gp: 412.0, network: 96.4, gpFull: 412.0, networkFull: 96.4 },
      { id: 'seguros', name: 'Seguros', connectionsThisMonth: 1, proPreviousMonth: true, proCurrentMonth: true, gp: 98.2, network: 21.9, gpFull: 98.2, networkFull: 21.9 },
    ],
    requirements,
    history: history(true),
  },
  diasMetaBatida: { days: 195, goal: 90 },
};
